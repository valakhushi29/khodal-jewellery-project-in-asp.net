﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class ClientSide_ClientRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

  
   
    protected void btnsubmit_Click(object sender, EventArgs e)
    {

        string constr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True";
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        string str = "insert into Registration values(@unm, @psw, @age, @gender, @address, @city, @state, @country, @contactno, @emailid)";
        SqlCommand cmd = new SqlCommand(str, con);
        cmd.Parameters.AddWithValue("@unm", txtunm.Text);
        cmd.Parameters.AddWithValue("@psw", txtpsw.Text);
        cmd.Parameters.AddWithValue("@age", txtage.Text);
        cmd.Parameters.AddWithValue("@gender", RadioButtonList1.Text);
        cmd.Parameters.AddWithValue("@city", DropDownList1.Text);
        cmd.Parameters.AddWithValue("@emailid", txtemailid.Text);

        cmd.Parameters.AddWithValue("@address", txtaddress.Text);
        cmd.Parameters.AddWithValue("@state", txtstate.Text);
        cmd.Parameters.AddWithValue("@country", txtcountry.Text);
        cmd.Parameters.AddWithValue("@contactno", txtcontactno.Text);
        int ans = cmd.ExecuteNonQuery();

        if (ans > 0)
        {
            txtunm.Text = "";
            txtpsw.Text = "";
            txtaddress.Text = "";
            txtcontactno.Text = "";
            RadioButtonList1.SelectedIndex = 1;
            DropDownList1.SelectedIndex = 1;
            txtcountry.Text = "";
            txtemailid.Text = "";
            txtage.Text = "";
            txtstate.Text = "";
            
        }
        Response.Redirect("~/ClientSide/ClientLogin.aspx");


    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtunm.Text = "";
        txtpsw.Text = "";
        txtaddress.Text = "";
        txtcontactno.Text = "";
        txtcountry.Text = "";
        txtemailid.Text = "";
        txtage.Text = "";
        txtstate.Text = "";

    }

  
}