﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class ClientSide_CEarrings : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adapter;
    DataTable dt;
    SqlDataReader reader;

    protected void Page_Load(object sender, EventArgs e)
    {
        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        //create new sqlconnection and connection to database by using connection string from web.config file  
        con = new SqlConnection(strcon);
        con.Open();

        fillgrid();
    }
    void fillgrid()
    {

        DataList1.DataSource = data();



        DataList1.DataBind();


    }

    public DataTable data()
    {
        SqlCommand cmd = new SqlCommand("select * from allproducts where product_cat = 'Earrings'", con);

        adapter = new SqlDataAdapter(cmd);

        dt = new DataTable();

        adapter.Fill(dt);
        return dt;

    }

}
