﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ClientSide_ClientContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            String connstr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connstr);
            conn.Open();
            String s1 = "select * from ContactUs";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Label1.Text = dr["Sname"].ToString();
                Label2.Text = dr["Oname"].ToString();
                Label3.Text = dr["Address"].ToString();
                Label4.Text = dr["Contactno"].ToString();
            }
            dr.Close();
            conn.Close();
        }


    }
}