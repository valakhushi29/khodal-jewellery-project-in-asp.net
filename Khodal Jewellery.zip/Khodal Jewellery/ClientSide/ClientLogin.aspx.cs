﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ClientSide_ClientLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtunm.Focus();

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        string connstr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True";
        SqlConnection conn = new SqlConnection(connstr);
        conn.Open();
        string str = "select * from Registration where unm=@unm and psw=@psw";
        SqlCommand cmd = new SqlCommand(str, conn);
        cmd.Parameters.AddWithValue("@unm", txtunm.Text);
        cmd.Parameters.AddWithValue("@psw", txtpsw.Text);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        int ans = cmd.ExecuteNonQuery();
        conn.Close();
        if (dt.Rows.Count > 0)
        {
            Session["User"] = txtunm.Text;
            Response.Redirect("~/ClientSide/proaddcart.aspx");
            Session.RemoveAll();
        }
        else
        {
            lblmsg.Text = "";
            lblmsg.Text = "Invalid UserName and Password";
        }
   }


    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtunm.Text = " ";
        txtpsw.Text = " ";
        lblmsg.Text = " ";
        Response.Redirect("~/ClientSide/ClientHome.aspx");

    }
}
