﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class AdminSide_AdminProductItem : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adapter;
    DataTable dt;
    SqlDataReader reader;
    protected void Page_Load(object sender, EventArgs e)
    {
        string strcon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        //create new sqlconnection and connection to database by using connection string from web.config file  
        con = new SqlConnection(strcon);
        con.Open();
        data_show();

    }

    protected void b1_Click(object sender, EventArgs e)
    {
        fileupload.SaveAs(Server.MapPath("~/images/" + fileupload.FileName));

        lable.Text = "success";

        string imgsrc = "~/images/" + fileupload.PostedFile.FileName;


        cmd = new SqlCommand("insert into allproducts (product_name,product_price,product_descreption,product_rating,product_image,product_cat)values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + imgsrc + "','" + TextBox5.Text + "')", con);

        cmd.ExecuteNonQuery();

        TextBox1.Text = string.Empty;
        TextBox2.Text = string.Empty;
        TextBox3.Text = string.Empty;
        TextBox4.Text = string.Empty;
        TextBox5.Text = string.Empty;

        data_show();

    }

    void data_show()
    {

        cmd = new SqlCommand("SELECT * from allproducts", con);

        adapter = new SqlDataAdapter(cmd);

        dt = new DataTable();

        adapter.Fill(dt);

        GridView1.DataSource = dt;
        GridView1.DataBind();

    }

    protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
    {
        cmd = new SqlCommand("delete from allproducts where id = '" + GridView1.Rows[e.RowIndex].Cells[2].Text + "'", con);
        cmd.ExecuteNonQuery();
        data_show();
    }

    
}