﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AdminSide_AdminGallery : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand cmd;
    string connstr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True";
   
    protected void btnupload_Click(object sender, EventArgs e)
    {
        try
        {
            string filename = FileUpload1.PostedFile.FileName;
            Server.HtmlEncode(FileUpload1.FileName);
            string ext = System.IO.Path.GetExtension(filename);
            if ((ext == ".jpg") || (ext == ".jpeg") || (ext == ".png") || (ext == ".bmp"))
            {
                FileUpload1.SaveAs(Server.MapPath("~/AdminSide/Aimages/" + filename));
                con = new SqlConnection(connstr);
                con.Open();
                cmd = new SqlCommand("insert into Gallery(image)values(@image)", con);
                cmd.Parameters.AddWithValue("@image", "Aimages/" + filename);
                cmd.ExecuteNonQuery();
                GridView1.DataBind();
                lblmsg.Text = "Record Insert Successfully...";
            }
            else
            {
                lblmsg.Text = "Problem for Inserting Image...";
            }
        }
        catch (Exception ex)
        {
            btnupload.Text = ex.Message;

        }
    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
