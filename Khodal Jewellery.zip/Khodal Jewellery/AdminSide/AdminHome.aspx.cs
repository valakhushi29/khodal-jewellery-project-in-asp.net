﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class AdminSide_AdminHome : System.Web.UI.Page
{

  
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox1.Focus();

    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        string constr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True";
        SqlConnection con = new SqlConnection(constr);
        con.Open();
        String str = "insert into home values(@hdescription)";
        SqlCommand cmd = new SqlCommand(str, con);
        cmd.Parameters.AddWithValue("@hdescription", TextBox1.Text);
        cmd.ExecuteNonQuery();
        GridView1.DataBind();
        Label2.Text = "submitted....";
        TextBox1.Text = "";
        Label2.Text = "";
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        
        TextBox1.Focus();
        TextBox1.Text = "";
        Label2.Text = "";

    }

    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }

   
}