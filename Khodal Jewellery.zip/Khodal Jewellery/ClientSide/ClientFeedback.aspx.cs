﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class ClientSide_ClientFeedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string constr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database.mdf;Integrated Security=True";

        SqlConnection con = new SqlConnection(constr);
        con.Open();
        string str = "insert into feedback values (@fnm,@femailid,@fcmnt)";
        SqlCommand cmd = new SqlCommand(str, con);
        cmd.Parameters.AddWithValue("@fnm", txtnm.Text);
        cmd.Parameters.AddWithValue("@femailid", txtemailid.Text);
        cmd.Parameters.AddWithValue("@fcmnt", txtcmnt.Text);
        int ans = cmd.ExecuteNonQuery();

        if (ans > 0)
        {
            Label5.Text = "Submmitted";
            txtnm.Text = "";
            txtemailid.Text = "";
            txtcmnt.Text = "";
        }
        else
            Label5.Text = "Not Submitted";
    }

    protected void Button2_click(object sender, EventArgs e)
    {
        txtnm.Text = "";
        txtemailid.Text = "";
        txtcmnt.Text = "";
        Label5.Text = "";
    }
}
